const headers = document.querySelectorAll('th');
const fruits = headers[0];
const counties = headers[1];

const trs = document.querySelectorAll('tr');

oldFruitList = [];
oldCountyList = [];

fruitList = [];
countyList = [];

for(i = 1; i < trs.length; i++) {
    fruitList.push(trs[i].children[0].innerHTML);
    countyList.push(trs[i].children[1].innerHTML);
    oldFruitList.push(trs[i].children[0].innerHTML);
    oldCountyList.push(trs[i].children[1].innerHTML);
}


sortedFruitList = fruitList.sort();
sortedCountyList = countyList.sort();

fruits.addEventListener("click", () => {
    console.log('gyümi');
    for(i = 1; i < trs.length; i++) {
        trs[i].children[0].innerHTML = sortedFruitList[i-1];
        trs[i].children[1].innerHTML = oldCountyList[i-1];
    }
});

counties.addEventListener("click", () => {
    console.log('megye');
    for(i = 1; i < trs.length; i++) {
        trs[i].children[0].innerHTML = oldFruitList[i-1];
        trs[i].children[1].innerHTML = sortedCountyList[i-1];
    }
});