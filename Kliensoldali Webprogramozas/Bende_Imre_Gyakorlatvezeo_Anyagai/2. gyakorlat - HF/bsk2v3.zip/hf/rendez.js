const table = document.getElementById("myTable");
const gyumolcsHeader = document.getElementById("gyumolcsHeader");
const megyeHeader = document.getElementById("megyeHeader");

function sortTable(column) {
    let rows = Array.from(table.getElementsByTagName("tr"));
    let order = 1;
    if (column.dataset.order === "1") {
        order = -1;
    }
    rows.sort(function(rowA, rowB) {
        let cellA = rowA.getElementsByTagName("td")[column.cellIndex];
        let cellB = rowB.getElementsByTagName("td")[column.cellIndex];
        if (!cellA || !cellB) {
            return 0;
        }
        let cellAValue = cellA.innerHTML.trim();
        let cellBValue = cellB.innerHTML.trim();
        if (cellAValue < cellBValue) {
            return -1 * order;
        } else if (cellAValue > cellBValue) {
            return 1 * order;
        } else {
            return 0;
        }
    });
    for (let i = 0; i < rows.length; i++) {
        table.tBodies[0].appendChild(rows[i]);
    }
    column.dataset.order = order;
}


gyumolcsHeader.addEventListener("click", function() {
    sortTable(this);
});

megyeHeader.addEventListener("click", function() {
    sortTable(this);
});