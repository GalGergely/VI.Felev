document.addEventListener('click', (event) => {
    let table = document.querySelector("table");
    let headers = Array.from(document.querySelectorAll("th"));
    let rows = Array.from(document.querySelectorAll("tr"))
    rows.shift()

    table.innerHTML = ''
    const index = headers.indexOf(event.target)
    rows.sort(function(a, b) {
        let aText = a.children[index].innerText
        let bText = b.children[index].innerText

        if (aText < bText) {
            return -1
        }

        if (aText > bText) {
            return 1
        }

        return 0
    })

    let html = ''
    headers.forEach(h => {
        html += `<th>${h.innerHTML}</th>`
    })
    rows.forEach(r => {
        html += `<tr>${r.innerHTML}</tr>`
    })
    table.innerHTML = html
})