// Rendezhető táblázat Adott egy táblázat az oldalon. 
// JavaScript segítségével tedd lehetővé, hogy az oszlopok fejlécére
// kattintva a táblázat az adott oszlop szerint rendezve jelenjen meg!

const table = document.querySelector('table');
const tableBody = table.querySelector('tbody');
const rowsBeta = tableBody.querySelectorAll('tr');
const rows = [].slice.call(rowsBeta, 1); 

function mySort(index) {
    const newRows = Array.from(rows);

    newRows.sort(function (rowA, rowB) {
        const cellA = rowA.querySelectorAll('td').item(index).innerHTML;
        const cellB = rowB.querySelectorAll('td').item(index).innerHTML;

        switch (true) {
            case cellA > cellB:
                return 1;
            case cellA < cellB:
                return -1;
            case cellA === cellB:
                return 0;
        }
    });

    rows.forEach(row => {
        tableBody.removeChild(row);
        console.log(row)
    });
    newRows.forEach(row => {
        tableBody.appendChild(row);
        console.log(row)
    });
}

const header1 = document.querySelector('th:first-child');
header1.addEventListener('click', event => {
    console.log("katt")
    mySort(0)
});
const header2 = document.querySelector('th:nth-child(2)');
header2.addEventListener('click', event => {
    console.log("katt2")
    mySort(1)
});
















// const header1 = document.querySelector('th:first-child');
// header1.addEventListener('click', event => {
//     console.log("katt")

// });

// const header2 = document.querySelector('th:nth-child(2)');
// header2.addEventListener('click', event => {
//     const col = document.querySelectorAll('td:nth-child(2)')
//     const items = []
//     col.forEach(elem => {
//         items.push(elem.innerText)
//     });
//     let res = items.sort()
//     let i = 0
//     col.forEach(elem => {
//         elem.innerHTML(res[i])
//         i++
//     });

//     console.log(res)



// });

