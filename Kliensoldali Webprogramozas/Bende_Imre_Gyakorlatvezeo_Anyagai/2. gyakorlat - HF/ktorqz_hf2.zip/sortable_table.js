class SortableTable {
    constructor(table) {
        this.originalTable = table;
        this.data = []
    }

    init() {
        this.collectData()
        this.originalTable.addEventListener('click', (e) => {
            if (e.target.matches('th')) {
                const colIndex = e.target.cellIndex
                this.sortTable(colIndex)
            }
        })
    }

    collectData() {
        this.tableRows = this.originalTable.querySelectorAll('tr')
        this.tableRows.forEach(row => {
            const rowData = []
            row.querySelectorAll('td').forEach(data => {
                rowData.push(data.innerText)
            })
            this.data.push(rowData)
        });
    }

    sortTable(colIndex) {
        this.data.sort((a, b) => a[colIndex] < b[colIndex] ? -1 : 1)

        this.tableRows.forEach(row => {
            if (row.rowIndex !== 0) {
                const rowHtml =
                `
                    <tr>
                        ${this.data[row.rowIndex].map(data => `
                            <td>
                                ${data}
                            </td>
                        `).join('')}
                    </tr>
                `
                row.innerHTML = rowHtml
            }
        })
    }
}

const sortableTable = new SortableTable(
    document.querySelector('table')
)

sortableTable.init()