const table = document.querySelector('table');
const headers = table.querySelectorAll('th');
const body = table.querySelector('tbody');
const rowsWithHeader = body.querySelectorAll('tr');
const rows = [].slice.call(rowsWithHeader, 1); // rows without the header row

for (let i = 0; i < headers.length; i++) {
    let currentHeader = headers[i];
    currentHeader.addEventListener('click', e => {  // adding event listeners to all headers          
        sortByColoumn(i);                               // and calling the sorting function when any of them is clicked
    });
}

function sortByColoumn(i) {
    const rowsCreated = Array.from(rows);
    rowsCreated.sort(function (r1, r2) {
        const c1 = r1.querySelectorAll('td')[i].innerText;
        const c2 = r2.querySelectorAll('td')[i].innerText;
        if (c1 > c2) { return 1; }
        else if (c1 < c2) { return -1; } // Comparing cells from the clicked coloumn
        else { return 0; }
    });
    rows.forEach(row => {
        body.removeChild(row); // removing orginal, not sorted rows
    });
    rowsCreated.forEach(row => {
        body.appendChild(row); // appending new, sorted rows
    });
}
