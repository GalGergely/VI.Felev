document.querySelectorAll('th').forEach(th => th.addEventListener('click', (() => {
    const table = th.closest('table');
    const index = Array.from(document.querySelectorAll('th')).indexOf(th)
    let inOrder = false

    Array.from(table.querySelectorAll('tr:nth-child(n+2)')).sort(function(a, b){
        const t1 = a.getElementsByTagName('td')[index].innerText.toLowerCase()
        const t2 = b.getElementsByTagName('td')[index].innerText.toLowerCase()

        if (t1 < t2) {
            inOrder = true
        }

        return (t1 > t2) ? 1 : -1
    }).forEach(tr => table.appendChild(tr))

    if (!inOrder) {
        Array.from(table.querySelectorAll('tr:nth-child(n+2)')).sort(function(a, b){
            const t1 = a.getElementsByTagName('td')[index].innerText.toLowerCase()
            const t2 = b.getElementsByTagName('td')[index].innerText.toLowerCase()

            return (t1 > t2) ? -1 : 1
        }).forEach(tr => table.appendChild(tr))
    }
})));