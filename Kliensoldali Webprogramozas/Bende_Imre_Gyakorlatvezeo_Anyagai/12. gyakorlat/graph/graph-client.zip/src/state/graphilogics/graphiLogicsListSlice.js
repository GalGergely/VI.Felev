import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const initialState = {
  puzzles: [],
};

export const graphiLogicsListSlice = createSlice({
  name: "graphilogicsList",
  initialState,
  reducers: {
    setList: (state, { payload }) => {
      state.puzzles = payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchList.fulfilled, (state, { payload: puzzles }) => {
      state.puzzles = puzzles;
    });
  },
});

export const graphiLogicsListReducer = graphiLogicsListSlice.reducer;
export const { setList } = graphiLogicsListSlice.actions;

export const fetchList = createAsyncThunk(
  "graphiLogicsList/fetchList",
  async () => {
    const response = await fetch("http://localhost:3030/puzzles");
    const jsonResponse = await response.json();
    return jsonResponse.data;
  }
);
