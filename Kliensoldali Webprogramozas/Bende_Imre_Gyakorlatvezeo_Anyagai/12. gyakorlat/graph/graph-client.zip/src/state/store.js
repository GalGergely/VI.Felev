import { configureStore } from "@reduxjs/toolkit";
import { authApiSlice } from "./auth/authApiSlice";
import { authReducer } from "./auth/authSlice";
import { graphiLogicsApiSlice } from "./graphilogics/graphiLogicsApiSlice";
import {
  graphiLogicsReducer,
  graphiLogicsSlice,
} from "./graphilogics/graphiLogicsSlice";

export const store = configureStore({
  reducer: {
    graphiLogics: graphiLogicsReducer,
    [graphiLogicsApiSlice.reducerPath]: graphiLogicsApiSlice.reducer,
    auth: authReducer,
    [authApiSlice.reducerPath]: authApiSlice.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
      .concat(graphiLogicsApiSlice.middleware)
      .concat(authApiSlice.middleware),
  devTools: {
    actionCreators: {
      actionCreators: graphiLogicsSlice.actions,
    },
  },
});
