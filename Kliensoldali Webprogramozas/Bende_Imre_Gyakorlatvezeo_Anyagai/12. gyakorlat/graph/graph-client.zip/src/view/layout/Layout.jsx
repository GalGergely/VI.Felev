import { Outlet } from "react-router-dom";
import { AuthStatus } from "../auth/AuthStatus";

export const Layout = () => (
  <div>
    <h1>GraphiLogics</h1>
    <AuthStatus />
    <Outlet />
  </div>
);
