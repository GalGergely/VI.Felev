import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Login } from "./auth/Login";
import { RequireAuth } from "./auth/RequireAuth";
import Graphilogics from "./graphilogics/Graphilogics";
import { Layout } from "./layout/Layout";

function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <RequireAuth>
                <Graphilogics />
              </RequireAuth>
            }
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
