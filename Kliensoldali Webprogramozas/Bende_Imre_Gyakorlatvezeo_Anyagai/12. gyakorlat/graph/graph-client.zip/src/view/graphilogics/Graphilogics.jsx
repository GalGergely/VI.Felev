import {
  useGetGraphiLogicsQuery,
  useGetSolutionsQuery,
} from "../../state/graphilogics/graphiLogicsApiSlice";

const usePuzzles = () => {
  const { data: puzzles, isSuccess: isSuccessPuzzles } =
    useGetGraphiLogicsQuery();
  console.log(puzzles);
  const { data: solutions, isSuccess: isSuccessSolutions } =
    useGetSolutionsQuery();
  console.log(solutions);

  if (!isSuccessPuzzles || !isSuccessSolutions) {
    return {
      puzzles: null,
      isSuccess: false,
    };
  }

  const getStatus = (puzzle, solutions) => {
    const solution = solutions.find(
      (solution) => solution.puzzleId === puzzle.id
    );
    return solution ? (solution.solved ? "solved" : "started") : "new";
  };
  const extendedPuzzles = puzzles.map((puzzle) => ({
    ...puzzle,
    status: getStatus(puzzle, solutions),
  }));
  console.log(extendedPuzzles);

  return {
    puzzles: extendedPuzzles,
    isSuccess: true,
  };
};

export const GraphiLogics = () => {
  // const { puzzle } = useGetGraphiLogicsQuery(undefined, {
  //   selectFromResult: ({ data }) => ({
  //     puzzle: data?.find((puzzle) => puzzle.id === 1),
  //   }),
  // });
  // console.log(puzzle);
  const { puzzles, isSuccess } = usePuzzles();

  if (!isSuccess) {
    return "Loading";
  }

  return (
    <table id="layout">
      <tbody>
        <tr>
          <td></td>
          <td>
            <table id="felso">
              <tbody>
                <tr>
                  <td>
                    <span>1</span>
                    <span>2</span>
                  </td>
                  <td>
                    <span>1</span>
                  </td>
                  <td>
                    <span>1</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr>
          <td>
            <table id="bal">
              <tbody>
                <tr>
                  <td>
                    <span>1</span>
                    <span>1</span>
                  </td>
                </tr>
                <tr>
                  <td></td>
                </tr>
                <tr>
                  <td>
                    <span>1</span>
                  </td>
                </tr>
                <tr>
                  <td>
                    <span>2</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
          <td>
            <table id="tabla">
              <tbody>
                <tr>
                  <td className="feher"></td>
                  <td className="szurke"></td>
                  <td className="fekete"></td>
                </tr>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  );
};

export default GraphiLogics;
