export function HaikuList() {
  return (
    <div>
      <h2>Haiku list</h2>
      <div>
        {/* prettier-ignore */}
        <pre>Téged vártalak
Mint hajnali fényt éjjel
Félve-remélve</pre>
        <button>Remove</button>
      </div>
    </div>
  );
};
