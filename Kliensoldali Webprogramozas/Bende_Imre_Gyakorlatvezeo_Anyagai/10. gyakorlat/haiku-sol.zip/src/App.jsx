import { Haiku } from "./features/haiku/Haiku";

function App() {
  return <Haiku />;
}

export default App;
