import { useDispatch, useSelector } from "react-redux";
import styles from "./Editor.module.css";
import { add, changeText, save, selectEditedText, selectSelectedIndex } from "./haikuSlice";

export function Editor() {
  const { text, isHaiku, vowelsPerRow } = useSelector(selectEditedText);
  const index = useSelector(selectSelectedIndex);
  const dispatch = useDispatch();

  return (
    <div>
      <textarea
        rows="4"
        cols="40"
        className={isHaiku ? styles.good : styles.wrong}
        value={text}
        onChange={(e) => dispatch(changeText(e.target.value))}
      ></textarea>
      <p>Vowels per row: {vowelsPerRow.join(',')}</p>
      {isHaiku && <button onClick={() => dispatch(add(text))}>Add</button>}
      {isHaiku && index !== null && <button onClick={() => dispatch(save(text))}>Save</button>}
    </div>
  );
};
