function DateTime() {
    var date = new Date();
    return (
        <>
            <div>
                <p> The current local time is: {date.toLocaleDateString()} {date.toLocaleTimeString()}</p>
            </div>
        </>
    )
}

export default DateTime