import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
import DateTime from "./date.jsx";

const root = ReactDOM.createRoot(document.getElementById('root'));

function tick() {
    const element = (
        <div>
            <App></App>
            <DateTime></DateTime>
        </div>
    );
    root.render(element);
}
setInterval(tick, 1000);
