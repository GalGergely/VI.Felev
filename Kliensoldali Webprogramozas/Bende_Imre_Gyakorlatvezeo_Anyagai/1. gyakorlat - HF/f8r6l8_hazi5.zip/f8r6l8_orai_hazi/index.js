// 1. feladat 
const navBar = document.querySelector('nav');
navBar.addEventListener('click', e => {
    if (e.target.matches('a[href^="#"]')) {
        e.preventDefault();
        const idSelector = e.target.hash;
        const anchorTarget = document.querySelector(idSelector);
        anchorTarget.scrollIntoView({ behavior: 'smooth' });
    }
});


// 2. feladat
function throttle(fn, time) {
    let timeoutId;
    return (...args) => {
      if (timeoutId) {
        return;
      }
      fn(...args);
      timeoutId = setTimeout(() => {
        timeoutId = null;
      }, time);
    };
  }

  document.addEventListener('scroll', throttle(() => {
    //console.log('scroll');
    const scrolledPxs = window.scrollY;
    if (scrolledPxs > 200) {
        navBar.classList.add('navbar-scrolled');
    }
    else {
        navBar.classList.remove('navbar-scrolled');
    }
  }, 30)
  );


// 3. feladat
const animationObserver = new IntersectionObserver(entries => {
    entries
        .filter(entry => entry.isIntersecting)
        .forEach(entry => {
            const element = entry.target;
            element.classList.add('animate__animated');
            element.classList.add('animate__' + element.getAttribute('data-scroll-animation'));
        });
});

document.querySelectorAll('[data-scroll]').forEach(elem => {
    animationObserver.observe(elem);
});


// 4. feladat
document.addEventListener('scroll', throttle(() => {
    const scrolled = window.scrollY;
    const viewPortHeight = document.body.clientHeight;
    const scrollHeight = document.body.scrollHeight;
    const maxScroll = scrollHeight - viewPortHeight;
    const scrolledPercentage = scrolled / maxScroll * 100;
    document.querySelector('.loading').style.width = `${scrolledPercentage}%`;
}, 30));


// HF: 5,6,7 feladatok közül választani

// 5. feladat
const sections = document.querySelectorAll('section');
const menuPoints = navBar.querySelectorAll('a');
document.addEventListener('scroll', throttle(() => {
  current = "";
  
  sections.forEach(section => {
    const sectionTop = section.offsetTop;
    if (scrollY >= sectionTop - 270) {
      current = section.getAttribute('id'); }
  });

  menuPoints.forEach(menupoint => {
    menupoint.classList.remove('active');
    if (menupoint.getAttribute('href') === `#${current}`) {
      menupoint.classList.add('active');
    }
  });
}, 30));