//1. feladat
const navBar = document.querySelector('nav');
navBar.addEventListener('click', event => {
    if(event.target.matches('a[href^="#"]')) {
        event.preventDefault();
        //event.target.classList.add("active");
        const idSelector = event.target.hash;
        const anchorTarget = document.querySelector(idSelector);
        anchorTarget.scrollIntoView({ behavior: 'smooth'});
    }
});

//2. feladat
function throttle(fn, time) {
    let timeoutId;
    return (...args) => {
        if (timeoutId) {
            return;
        }
        fn(...args);
        timeoutId = setTimeout(() => {
            timeoutId = null;
        }, time);
    };
}

document.addEventListener('scroll', throttle(() => {
    const scrolledPxs = window.scrollY;
    if (scrolledPxs > 200) {
        navBar.classList.add('navbar-scrolled');
    } else {
        navBar.classList.remove('navbar-scrolled');
    }
}, 30));

//3. feladat
const animationObserver = new IntersectionObserver(entries => {
    entries.filter(entry => entry.isIntersecting)
        .forEach(entry => {
            const element = entry.target;
            element.classList.add('animate__animated');
            element.classList.add('animate__' + element.getAttribute('data-scroll-animation'));
        })
});


document.querySelectorAll('[data-scroll]').forEach(elem => {
    animationObserver.observe(elem);
});

//4. feladat
/*document.addEventListener('scroll', throttle(() => {
    const scrolled = window.scrollY;
    const viewPortHeight = document.body.clientHeight;
    const scrollHeight = document.body.scrollHeight;
    const maxScroll = scrollHeight - viewPortHeight;
    const scrolledPercentage = scrolled / maxScroll * 100;
    document.querySelector('.loading').style.width = `${scrolledPercentage}%`;
},30));*/

//szorg 5,6,7

//5. feladat - szorgalmi

const sections = document.querySelectorAll('section');
const navLinks = document.querySelectorAll('nav ul li a');

document.addEventListener('scroll', throttle(() => {
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (scrollY >= sectionTop - sectionHeight / 3) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
    });

    navLinks.forEach(link => {
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
},30));






