// 1
const navBar = document.querySelector('nav');
navBar.addEventListener('click', event => {
    if (event.target.matches('a[href^="#"]')) {
        event.preventDefault();
        const idSelector = event.target.hash;
        const anchorTarget = document.querySelector(idSelector);
        anchorTarget.scrollIntoView({ behavior: 'smooth' });
    }
});


// 2
function throttle(fn, time) {
    let timeoutId;
    return (...args) => {
        if (timeoutId) {
            return;
        }
        fn(...args);
        timeoutId = setTimeout(() => {
            timeoutId = null;
        }, time);
    };
}

document.addEventListener('scroll', throttle(() => {
    const scrolledPx = window.scrollY;
    var nav = document.getElementById("mainNav");
    if (scrolledPx > 200) {
        nav.classList.add("navbar-scrolled");
    } else {
        nav.classList.remove("navbar-scrolled");
    }
}, 30));


// 3
const animationObserver = new IntersectionObserver(entries => {
    entries
        .filter(entry => entry.isIntersecting)
        .forEach(entry => {
            const element = entry.target;
            element.classList.add('animate__animated');
            element.classList.add('animate__' + element.getAttribute('data-scroll-animation'));
        });
});
document.querySelectorAll('[data-scroll]').forEach(elem => {
    animationObserver.observe(elem);
});


// 4
document.addEventListener('scroll', throttle(() => {
    const scrolledPx = window.scrollY;
    const viewPortHeight = document.body.clientHeight;
    const scrollHeight = document.body.scrollHeight;
    const maxScroll = scrollHeight - viewPortHeight;
    const scrolledPercentage = scrolledPx / maxScroll * 100
    var load = document.querySelector('.loading')
    load.style.width = `${scrolledPercentage}%`;
}, 10));


// 5
document.addEventListener('scroll', throttle(() => {
    const scrolledPx = window.scrollY;
    const viewPortHeight = document.body.clientHeight;
    const scrollHeight = document.body.scrollHeight;
    const maxScroll = scrollHeight - viewPortHeight;
    const scrolledPercentage = scrolledPx / maxScroll * 100
    console.log(scrolledPercentage)
    const buttons = document.querySelectorAll('.nav-link')
    if (scrolledPercentage > 7 && scrolledPercentage < 39) {
        buttons.item(0).classList.add('active');
        buttons.item(1).classList.remove('active');
        buttons.item(2).classList.remove('active');
        buttons.item(3).classList.remove('active');
        console.log('1');
    }else if (scrolledPercentage >= 39 && scrolledPercentage < 57) {
        buttons.item(0).classList.remove('active');
        buttons.item(1).classList.add('active');
        buttons.item(2).classList.remove('active');
        buttons.item(3).classList.remove('active');
        console.log('2');
    }else if (scrolledPercentage >= 57 && scrolledPercentage < 92) {
        buttons.item(0).classList.remove('active');
        buttons.item(1).classList.remove('active');
        buttons.item(2).classList.add('active');
        buttons.item(3).classList.remove('active');
        console.log('3');
    }else if (scrolledPercentage >= 92) {
        buttons.item(0).classList.remove('active');
        buttons.item(1).classList.remove('active');
        buttons.item(2).classList.remove('active');
        buttons.item(3).classList.add('active');
        console.log('4');
    }
    else if (scrolledPercentage <= 7) {
        buttons.item(0).classList.remove('active');
        buttons.item(1).classList.remove('active');
        buttons.item(2).classList.remove('active');
        buttons.item(3).classList.remove('active');
        console.log('5');
    }
}, 10));
