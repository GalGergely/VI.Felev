//1. feladat
const navBar = document.querySelector('nav');
navBar.addEventListener('click', event => {
    if (event.target.matches('a[href^="#"]')) {
        event.preventDefault();
        const idSelector = event.target.hash;
        const anchorTarget = document.querySelector(idSelector);
        anchorTarget.scrollIntoView({ behavior: 'smooth' });
    }
    
});

//2. feladat
window.addEventListener('scroll', throttle(() => {
    console.log('scroll');
    const scrolledPxs = window.scrollY;
    if (scrolledPxs > 200) {
        navBar.classList.add('navbar-scrolled');
    } else {
        navBar.classList.remove('navbar-scrolled');
    }
}, 30));

//3. feladat
const animationObserver = new IntersectionObserver(entries => {
    entries
        .filter(entry => entry.isIntersecting)
        .forEach(entry => {
            const element = entry.target;
            element.classList.add('animate__animated');
            element.classList.add('animate__' + element.getAttribute
            ('data-scroll-animation'));
        });
});

document.querySelectorAll('[data-scroll]').forEach(elem => {
    animationObserver.observe(elem);
});

//4. feladat
document.addEventListener('scroll', throttle(() => {
    const scrolled = window.scrollY;
    const viewPortHeight = document.body.viewPortHeight;
    const scrollHeight = document.body.scrollHeight;
    const maxScroll = scrollHeight - viewPortHeight;
    const scrolledPercentage = scrolled / maxScroll * 100;
    document.querySelector('.loading').style.width = `${scrolledPercentage}%`;
}, 30));

//5. feladat
const navi = document.querySelectorAll('a');
const section = document.querySelectorAll('section');

window.addEventListener('scroll', throttle(() => {
    current = '';
    section.forEach( sec => {
        const top = sec.offsetTop;
        const height = sec.clientHeight;
        if(scrollY >= (top - height / 3)) {
            current = sec.getAttribute('id');
        }
    });

    navi.forEach( li => {
        li.classList.remove('active');
        if(li.classList.contains(current)) {
            li.classList.add('active');
        }
    });
}, 30));