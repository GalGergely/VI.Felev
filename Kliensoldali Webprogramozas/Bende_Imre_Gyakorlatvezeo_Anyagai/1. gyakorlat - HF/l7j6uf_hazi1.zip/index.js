const navBar = document.querySelector('nav');
navBar.addEventListener('click', event => {
    if(event.target.matches('a[href^="#"]')){
        event.preventDefault();
        const idSelector = event.target.hash;
        const anchorTarget = document.querySelector(idSelector);
        anchorTarget.scrollIntoView({ behavior: 'smooth' });
    }
    
});
function throttle(fn, time) {
    let timeoutId;
    return (...args) => {
      if (timeoutId) {
        return;
      }
      fn(...args);
      timeoutId = setTimeout(() => {
        timeoutId = null;
      }, time);
    };
  }
//2.-4. feladat
  document.addEventListener('scroll', throttle(()=>{
    console.log('scroll');
    const scrolledPix = window.scrollY;
    if(scrolledPix > 200){
        navBar.classList.add('navbar-scrolled');
    }else{
        navBar.classList.remove('navbar-scrolled');
    }

    const viewPortH = document.body.clientHeight;
    const scrollH = document.body.scrollHeight;
    const maxScroll = scrollH - viewPortH;
    const scrollPercent = scrolledPix / maxScroll * 100;
    document.querySelector('.loading').style.width = `${scrollPercent}%`;
  }, 30));

  const animationObserver = new IntersectionObserver(entries =>{
    entries
        .filter(entry => entry.isIntersecting)
        .forEach(entry => {
                const element = entry.target;
                element.classList.add('animate__animated');
                element.classList.add('animate__' + element.getAttribute('data-scroll-animation'));
        });
  })

  document.querySelectorAll('[data-scroll]').forEach(elem =>{
    animationObserver.observe(elem);
  });

  //Házi: 5, 6 vagy 7
  //5
  const sections = document.querySelectorAll('section')
  //console.log(sections)
  const navItems = document.querySelectorAll('.nav-link')
  //console.log(navItems)
  function isInViewport(element){
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    )
  }
 document.addEventListener('scroll', throttle(()=>{
    sections.forEach(section => {
      if(isInViewport(section)){
        navItems.forEach(navitem => {
        if(navitem.getAttribute("href").match(`#${section.getAttribute("id")}`)){
          navitem.classList.add('active')
        }else if(navitem.classList.contains('active')){
          navitem.classList.remove('active')
        }
      }) 
      }
    })
  }, 30));