import './App.css'
import Hello from './Hello'

function App() {

  return (
    <div className="App">
      <Hello name="Imre" count={5}>
        <p>A small message for you!</p>
      </Hello>
    </div>
  )
}

export default App
