import { useState } from "react";

export const useForm = (defaultUsername, defaultPassword, next) => {
    const [username, setUsername] = useState(defaultUsername);
    const [password, setPassword] = useState(defaultPassword);
    const [errors, setErrors] = useState({});

    const handleUsername = (e) => {
        setUsername(e.target.value);
    }
    const handlePassword = (e) => {
        setPassword(e.target.value);
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(username,password);
        const newErrors = {};
        if(!username){
            newErrors.username = 'Username is required';
          }
        if(!password){
            newErrors.password = 'Password is required';
        }
        setErrors(newErrors);
        if(Object.values(newErrors).length > 0){
            return;
        }else{
            next();
        }
    }
    return{
        username,
        password,
        errors,
        handleUsername,
        handlePassword,
        handleSubmit
    }
}