import { Button, TextField } from "@mui/material";
import { useEffect, useRef, useState } from "react";
import styles from "./Login.module.css";

function Login ({ login }) {
  const usernameRef = useRef(null);
  const passwordRef = useRef(null);

  const [errors, setErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();

    const username = usernameRef.current.value;
    const password = passwordRef.current.value;

    const newErrors = {};

    if (username === '') {
      newErrors.username = 'Username is required';
    }
    if (password === '') {
      newErrors.password = 'Password is required';
    }

    setErrors(newErrors);

    if (Object.values(newErrors).length > 0) {
      return;
    }

    if (login) {
      login(username);
    }
  }

  console.log(errors);

  /*useEffect(() => {
    usernameRef.current.focus();
  }, []);*/

  return (
    <form className={styles.keretes} onSubmit={handleSubmit}>
      {/*<label htmlFor="username">Felhasználónév: </label>*/}
      <TextField
        inputRef={usernameRef}
        type="text"
        id="username"
        name="username"
        label="Felhasználónév"
        defaultValue=""
        variant="standard"
        error={errors.username !== undefined}
        helperText={errors.username}
        autoFocus
      />
      <br />
      {/*<label htmlFor="password">Jelszó: </label>*/}
      <TextField
        inputRef={passwordRef}
        type="password"
        id="password"
        name="password"
        label="Jelszó"
        defaultValue=""
        variant="standard"
        error={errors.password !== undefined}
        helperText={errors.password}
      />
      <br />
      <Button variant="contained" type="submit"> Elküld</Button>
    </form>
  );
};

export default Login;
