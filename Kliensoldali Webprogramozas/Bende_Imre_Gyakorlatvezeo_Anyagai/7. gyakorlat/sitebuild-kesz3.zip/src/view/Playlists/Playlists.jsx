import { examplePlaylists } from '../../domain/playlist'
import TrackDetails from './TrackDetails';
import Playlist from './Playlist';
import PlaylistList from './PlaylistList';
import { exampleTracks } from '../../domain/track';
import { useState } from 'react';

function Playlists() {
    const playlists = examplePlaylists;
    const tracks = exampleTracks;

    const defaultId = playlists[0].id;
    const [chosenPlaylistId, setChosenPlaylistId] = useState(defaultId);
    const chosenPlaylist = playlists.find(
        playlist => playlist.id === chosenPlaylistId
    );
    const [chosenTrackId, setChosenTrackId] = useState();
    const chosenTrack = tracks.find(
        track => track.id === chosenTrackId
    );

    const handleChosenPlaylist = id => {
        setChosenPlaylistId(id);
        setChosenTrackId(null);  
    };

    return (
        <div className="ui container">
        <h1>My Playlists</h1>
        <div className="ui stackable two column grid">
        <PlaylistList
            playlists={playlists}
            chosenPlaylistId={chosenPlaylistId}
            onChosePlaylist={handleChosenPlaylist}
        ></PlaylistList>
        <Playlist></Playlist>
        </div>
        <div className="ui divider"></div>
        <TrackDetails></TrackDetails>
    </div>
    )
}

export default Playlists