import { useState } from "react";
import { Modal } from 'semantic-ui-react';
import cn from 'classnames';

function useForm(defaultValue, validators) {
    const [formState, setFormState] = useState(defaultValue);
    const [validationState, setValidationState] = useState(() =>
      Object.keys(validators).reduce((defaultValidation, key) => {
        return {
          ...defaultValidation,
          [key]: validators[key](formState[key]),
        };
      }, {}),
    );
    const handleFormChange = e => {
      const { name, value } = e.target;
      setFormState({
        ...formState,
        [name]: value,
      });
      setValidationState({
        ...validationState,
        [name]: validators[name](value),
      });
    };
    const isValid = Object.values(validationState).every(validationResult => !validationResult);
    return {
      handleFormChange,
      formState,
      validationState,
      isValid,
    };
  }

function requiredValidator(fieldName) {
    return value => {
        if (value) {
            return null;
        } else {
            return `${fieldName} is required.`;
        }
    }
}

function TrackForm({onSubmit, track, closeModal, openModal, modalOpen}) {
    const {handleFormChange, formState, validationState, isValid } = useForm({
        artist: "",
        title: "",
        length: "",
        spotifyURL: "",
        chrodsURL: "",
        lyricsURL: ""
    }, {
        artist: requiredValidator('Author'),
        title: requiredValidator('Title'),
        length: requiredValidator('Length')
    })


    return(
      <Modal
        closeIcon
        noValidate
        as="form"
        open={modalOpen}
        onClose={closeModal}
        onOpen={openModal}
        onSubmit={e => {
          e.preventDefault();
          if (isValid) {
            onSubmit(formState);
            closeModal();
          }
        }}
        >
        <Modal.Header>Add new Track</Modal.Header>
        <Modal.Content>
          <Modal.Description>
              <div className={cn({ui: true, form: true, error: !isValid})}>
                <div className="three fields">
                    <div className={cn({field: true, error: validationState.artist})}>
                    <label>Author</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="John Williams" 
                      name="artist"
                      value={formState.artist}
                      onChange={handleFormChange}
                    />
                    </div>
                    <div className={cn({field: true, error: validationState.title})}>
                    <label>Track name</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="Imperial March" 
                      name="title"
                      value={formState.title}
                      onChange={handleFormChange}
                    />
                    </div>
                    <div className={cn({field: true, error: validationState.length})}>
                    <label>Length</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="3:11" 
                      name="length"
                      value={formState.length}
                      onChange={handleFormChange}
                    />
                    </div>
                </div>
                <div className="three fields">
                    <div className="field">
                    <label>Spotify URL</label>
                    <input 
                      name="spotifyURL"
                      value={formState.spotifyURL}
                      onChange={handleFormChange}
                      type="text" 
                      placeholder="https://" />
                    </div>
                    <div className="field">
                    <label>Lyrics URL</label>
                    <input 
                      name="lyricsURL"
                      value={formState.lyricsURL}
                      onChange={handleFormChange}
                      type="text" 
                      placeholder="https://" />
                    </div>
                    <div className="field">
                    <label>Guitar tab URL</label>
                    <input 
                      name="chordsURL"
                      value={formState.chordsURL}
                      onChange={handleFormChange}
                      type="text"
                      placeholder="https://" />
                    </div>
                </div>
                </div>
          </Modal.Description>
        </Modal.Content>
        <Modal.Actions>
            <div className="ui black deny button">
                Cancel
            </div>
            <div className="ui positive right labeled icon button">
                Add
                <i className="plus icon"></i>
            </div>
        </Modal.Actions>
      </Modal>
    )
}

export default TrackForm