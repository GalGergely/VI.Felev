function useForm(defaultValue, validators) {
    const [formState, setFormState] = useState(defaultValue);
    const [validationState, setValidationState] = useState(() =>
      Object.keys(validators).reduce((defaultValidation, key) => {
        return {
          ...defaultValidation,
          [key]: validators[key](formState[key]),
        };
      }, {}),
    );
    const handleFormChange = e => {
      const { name, value } = e.target;
      setFormState({
        ...formState,
        [name]: value,
      });
      setValidationState({
        ...validationState,
        [name]: validators[name](value),
      });
    };
    const isValid = Object.values(validationState).every(validationResult => !validationResult);
    return {
      handleFormChange,
      formState,
      validationState,
      isValid,
    };
  }

function requiredValidator(fieldName) {
    return value => {
        if (value) {
            return null;
        } else {
            return `${fieldName} is required.`;
        }
    }
}

function TrackForm() {
    const {handleFormChange, formState, validationState, isValid } = useForm({
        artist: "",
        title: "",
        length: "",
        spotifyURL: "",
        chrodsURL: "",
        lyricsURL: ""
    }, {
        artist: requiredValidator('Author'),
        title: requiredValidator('Title'),
        length: requiredValidator('Length')
    })


    return(
        <div className="ui modal">
            <i className="close icon"></i>
            <div className="header">Add new Track</div>
            <div className="image content">
            <div className="description">
                <form className="ui form">
                <div className="two fields">
                    <div className="field">
                    <label>Author</label>
                    <input required type="text" placeholder="John Williams" />
                    </div>
                    <div className="field">
                    <label>Track name</label>
                    <input required type="text" placeholder="Imperial March" />
                    </div>
                </div>
                <div className="three fields">
                    <div className="field">
                    <label>Spotify URL</label>
                    <input type="text" placeholder="https://" />
                    </div>
                    <div className="field">
                    <label>Lyrics URL</label>
                    <input type="text" placeholder="https://" />
                    </div>
                    <div className="field">
                    <label>Guitar tab URL</label>
                    <input type="text" placeholder="https://" />
                    </div>
                </div>
                </form>
            </div>
            </div>
            <div className="actions">
            <div className="ui black deny button">
                Cancel
            </div>
            <div className="ui positive right labeled icon button">
                Add
                <i className="plus icon"></i>
            </div>
            </div>
        </div>
    )
}

export default TrackForm