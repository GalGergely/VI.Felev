import { GraphiLogics } from "./graphilogics/Graphilogics";

function App() {
  return (
    <>
      <h1>GraphiLogics</h1>
      <GraphiLogics />
    </>
  )
}

export default App
