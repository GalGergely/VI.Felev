#include <SDL.h>
#include <iostream>

void drawPacehudoCube(SDL_Renderer* ren, Sint32 mouseX, Sint32 mouseY) {
	double radius = 80.0;
	const double angle_between_points = 360.0 / 4;
	double current_angle = 45.0;
	SDL_Point rectPoints[5];
	SDL_Point rect2Points[5];
	Sint32 myMouseX;
	Sint32 myMouseY;

	myMouseX = mouseX - 400;
	if (myMouseX > 20) {
		myMouseX = 20;
	}
	else if (myMouseX < -20) {
		myMouseX = -20;
	}

	myMouseY = mouseY - 300;
	if (myMouseY > 20) {
		myMouseY = 20;
	}
	else if (myMouseY < -20) {
		myMouseY = -20;
	}

	for (int i = 0; i < 4 + 1; i++) {
		double x = radius * std::cos((current_angle * M_PI / 180.0)) + 400 + myMouseX;
		double y = radius * std::sin((current_angle * M_PI / 180.0)) + 300 + myMouseY;
		SDL_Point point = { x, y };
		rectPoints[i] = point;
		current_angle += angle_between_points;
	}

	current_angle = 45.0;
	for (int i = 0; i < 4 + 1; i++) {
		double x = radius * std::cos((current_angle * M_PI / 180.0)) + 400 - myMouseX;
		double y = radius * std::sin((current_angle * M_PI / 180.0)) + 300 - myMouseY;
		SDL_Point point = { x, y };
		rect2Points[i] = point;
		current_angle += angle_between_points;
	}

	SDL_SetRenderDrawColor(ren, 0, 0, 0, 0);

	for (size_t i = 0; i < 4; i++)
	{
		size_t j;
		i == 4 ? j = 0 : j = i + 1;
		SDL_RenderDrawLine(ren, rectPoints[i].x, rectPoints[i].y, rectPoints[j].x, rectPoints[j].y);
		SDL_RenderDrawLine(ren, rect2Points[i].x, rect2Points[i].y, rect2Points[j].x, rect2Points[j].y);
		SDL_RenderDrawLine(ren, rectPoints[i].x, rectPoints[i].y, rect2Points[i].x, rect2Points[i].y);
		SDL_RenderDrawLine(ren, rectPoints[j].x, rectPoints[j].y, rect2Points[j].x, rect2Points[j].y);
	}
	SDL_RenderPresent(ren);
}

int main( int argc, char* args[] )
{
	// állítsuk be, hogy kilépés előtt hívja meg a rendszer az alábbi függvényt, ami a lambda törzsében található
	atexit([] {
			std::cout << "Press a key to exit the application..." << std::endl;
			std::cin.get();
		});

	//
	// 1. lépés: inicializáljuk az SDL-t
	//

	// a grafikus alrendszert kapcsoljuk csak be, ha gond van, akkor jelezzük és lépjün ki
	if ( SDL_Init( SDL_INIT_VIDEO ) == -1 )
	{
		// irjuk ki a hibat es terminaljon a program
		std::cout << "[SDL initialization] Error during the SDL initialization: " << SDL_GetError() << std::endl;
		return 1;
	}
			
	//
	// 2. lépés: hozzuk létre az ablakot, amire rajzolni fogunk
	//

	SDL_Window *win = nullptr;
    win = SDL_CreateWindow( "Hello SDL!",				// az ablak fejléce
							100,						// az ablak bal-felsõ sarkának kezdeti X koordinátája
							100,						// az ablak bal-felsõ sarkának kezdeti Y koordinátája
							800,						// ablak szélessége
							600,						// és magassága
							SDL_WINDOW_SHOWN);			// megjelenítési tulajdonságok

	// ha nem sikerült létrehozni az ablakot, akkor írjuk ki a hibát, amit kaptunk és lépjünk ki
    if (win == nullptr)
	{
		std::cout << "[Window creation] Error during the creation of an SDL window: " << SDL_GetError() << std::endl;
        return 1;
    }

	//
	// 3. lépés: hozzunk létre egy renderelõt, rajzolót
	//

    SDL_Renderer *ren = nullptr;
    ren = SDL_CreateRenderer(	win, // melyik ablakhoz rendeljük hozzá a renderert
								-1,  // melyik indexú renderert inicializáljuka
									 // a -1 a harmadik paraméterben meghatározott igényeinknek megfelelõ elsõ renderelõt jelenti
								SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);	// az igényeink, azaz
																						// hardveresen gyorsított és vsync-et beváró
    if (ren == nullptr)
	{
        std::cout << "[Renderer creation] Error during the creation of an SDL renderer: " << SDL_GetError() << std::endl;
        return 1;
    }

	//
	// 4. lépés: indítsuk el a fõ üzenetfeldolgozó ciklust
	// 

	// véget kell-e érjen a program futása?
	bool quit = false;
	// feldolgozandó üzenet ide kerül
	SDL_Event ev;
	// egér X és Y koordinátái
	Sint32 mouseX = 0, mouseY = 0;

	while (!quit)
	{
		// amíg van feldolgozandó üzenet dolgozzuk fel mindet:
		while ( SDL_PollEvent(&ev) )
		{
			switch (ev.type)
			{
			case SDL_QUIT:
				quit = true;
				break;
			case SDL_KEYDOWN:
				if ( ev.key.keysym.sym == SDLK_ESCAPE )
					quit = true;
				break;
			case SDL_MOUSEMOTION:
				mouseX = ev.motion.x;
				mouseY = ev.motion.y;
				break;
			case SDL_MOUSEBUTTONUP:
				// egérgomb felengedésének eseménye; a felengedett gomb a ev.button.button -ban található
				// a lehetséges gombok a következõek: SDL_BUTTON_LEFT, SDL_BUTTON_MIDDLE, 
				//		SDL_BUTTON_RIGHT, SDL_BUTTON_WHEELUP, SDL_BUTTON_WHEELDOWN
				break;
			}
		}

		// töröljük a hátteret fehérre
		SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
		SDL_RenderClear(ren);

		drawPacehudoCube(ren, mouseX, mouseY);

		// jelenítsük meg a backbuffer tartalmát
		SDL_RenderPresent(ren);
	}

	//
	// 4. lépés: lépjünk ki
	// 

	SDL_DestroyRenderer( ren );
	SDL_DestroyWindow( win );

	SDL_Quit();

	return 0;
}