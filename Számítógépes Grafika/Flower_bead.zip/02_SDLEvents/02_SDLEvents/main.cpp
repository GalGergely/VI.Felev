#include <SDL.h>
#include <iostream>


void drawFlowerLines(SDL_Renderer* ren, float rotation_speed) {
	const int num_points = 30;
	double radius = 80.0;
	const double angle_between_points = 360.0 / num_points;
	double current_angle = 0.0;
	SDL_Point outer[num_points + 1];
	SDL_Point inner[num_points + 1];

	for (int i = 0; i < num_points + 1; i++) {
		double x = radius * std::cos((current_angle * M_PI / 180.0 + rotation_speed) + 0.1) + 400;
		double y = radius * std::sin((current_angle * M_PI / 180.0 + rotation_speed) + 0.1) + 300;
		SDL_Point point = { x, y };
		inner[i] = point;
		current_angle += angle_between_points;
	}

	radius = 100.0;
	for (int i = 0; i < num_points + 1; i++) {
		double x = radius * std::cos(current_angle * M_PI / 180.0 + rotation_speed ) + 400;
		double y = radius * std::sin(current_angle * M_PI / 180.0 + rotation_speed ) + 300;
		SDL_Point point = { x, y };
		outer[i] = point;
		current_angle += angle_between_points;
	}

	SDL_SetRenderDrawColor(ren, 0, 0, 0, 0);
	
	for (size_t i = 0; i < num_points; i++)
	{
		size_t j;
		i == num_points ? j = 0 : j = i + 1;
		SDL_RenderDrawLine(ren, outer[i].x, outer[i].y, inner[i].x, inner[i].y);
		SDL_RenderDrawLine(ren, outer[i].x, outer[i].y, inner[j].x, inner[j].y);
	}
	SDL_RenderPresent(ren);
}

int main( int argc, char* args[] )
{
	// állítsuk be, hogy kilépés előtt hívja meg a rendszer az alábbi függvényt, ami a lambda törzsében található
	atexit([] {
			std::cout << "Press a key to exit the application..." << std::endl;
			std::cin.get();
		});

	//
	// 1. lépés: inicializáljuk az SDL-t
	//

	// a grafikus alrendszert kapcsoljuk csak be, ha gond van, akkor jelezzük és lépjün ki
	if ( SDL_Init( SDL_INIT_VIDEO ) == -1 )
	{
		// irjuk ki a hibat es terminaljon a program
		std::cout << "[SDL initialization] Error during the SDL initialization: " << SDL_GetError() << std::endl;
		return 1;
	}
			
	//
	// 2. lépés: hozzuk létre az ablakot, amire rajzolni fogunk
	//

	SDL_Window *win = nullptr;
    win = SDL_CreateWindow( "Hello SDL!",				// az ablak fejléce
							100,						// az ablak bal-felsõ sarkának kezdeti X koordinátája
							100,						// az ablak bal-felsõ sarkának kezdeti Y koordinátája
							800,						// ablak szélessége
							600,						// és magassága
							SDL_WINDOW_SHOWN);			// megjelenítési tulajdonságok

	// ha nem sikerült létrehozni az ablakot, akkor írjuk ki a hibát, amit kaptunk és lépjünk ki
    if (win == nullptr)
	{
		std::cout << "[Window creation] Error during the creation of an SDL window: " << SDL_GetError() << std::endl;
        return 1;
    }

	//
	// 3. lépés: hozzunk létre egy renderelõt, rajzolót
	//

    SDL_Renderer *ren = nullptr;
    ren = SDL_CreateRenderer(	win, // melyik ablakhoz rendeljük hozzá a renderert
								-1,  // melyik indexú renderert inicializáljuka
									 // a -1 a harmadik paraméterben meghatározott igényeinknek megfelelõ elsõ renderelõt jelenti
								SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);	// az igényeink, azaz
																						// hardveresen gyorsított és vsync-et beváró
    if (ren == nullptr)
	{
        std::cout << "[Renderer creation] Error during the creation of an SDL renderer: " << SDL_GetError() << std::endl;
        return 1;
    }

	//
	// 4. lépés: indítsuk el a fõ üzenetfeldolgozó ciklust
	// 

	// véget kell-e érjen a program futása?
	bool quit = false;
	// feldolgozandó üzenet ide kerül
	SDL_Event ev;
	// egér X és Y koordinátái
	Sint32 mouseX = 0, mouseY = 0;
	float rotation_speed = 0.01;
	float rotation_status = 0;


	while (!quit)
	{
		// amíg van feldolgozandó üzenet dolgozzuk fel mindet:
		while ( SDL_PollEvent(&ev) )
		{
			switch (ev.type)
			{
			case SDL_QUIT:
				quit = true;
				break;
			case SDL_KEYDOWN:
				if (ev.key.keysym.sym == SDLK_d) {
					rotation_speed += 0.01;
				}
				if (ev.key.keysym.sym == SDLK_a) {
					rotation_speed -= 0.01;
				}
				if (ev.key.keysym.sym == SDLK_RIGHT) {
					rotation_speed += 0.01;
				}
				if (ev.key.keysym.sym == SDLK_LEFT) {
					rotation_speed -= 0.01;
				}
				if ( ev.key.keysym.sym == SDLK_ESCAPE )
					quit = true;
				break;
			case SDL_MOUSEMOTION:
				mouseX = ev.motion.x;
				mouseY = ev.motion.y;
				break;
			case SDL_MOUSEBUTTONUP:
				// egérgomb felengedésének eseménye; a felengedett gomb a ev.button.button -ban található
				// a lehetséges gombok a következõek: SDL_BUTTON_LEFT, SDL_BUTTON_MIDDLE, 
				//		SDL_BUTTON_RIGHT, SDL_BUTTON_WHEELUP, SDL_BUTTON_WHEELDOWN
				break;
			}
		}

		// töröljük a hátteret fehérre
		SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
		SDL_RenderClear(ren);

		rotation_status += rotation_speed;
		drawFlowerLines(ren, rotation_status);

		// jelenítsük meg a backbuffer tartalmát
		SDL_RenderPresent(ren);
	}

	//
	// 4. lépés: lépjünk ki
	// 

	SDL_DestroyRenderer( ren );
	SDL_DestroyWindow( win );

	SDL_Quit();

	return 0;
}


